# Python if-else
#https://www.hackerrank.com/challenges/py-if-else/problem

import math
import os
import random
import re
import sys

if __name__ == '__main__':
    n = int(input().strip())

    # Check if the number is odd
    if n % 2 != 0:
        print("Weird")
    else:
        # The number is even, apply the sub-conditions
        if 2 <= n <= 5:
            print("Not Weird")
        elif 6 <= n <= 20:
            print("Weird")
        elif n > 20:
            print("Not Weird")