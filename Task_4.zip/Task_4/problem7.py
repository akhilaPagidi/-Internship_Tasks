# string split and join
# https://www.hackerrank.com/challenges/python-string-split-and-join/problem

def split_and_join(line):
    # write your code here
    x=line.split()
    return '-'.join(x)

if __name__ == '__main__':
    line = input()
    result = split_and_join(line)
    print(result)