#https://www.hackerrank.com/challenges/finding-the-percentage/problem
#FINDING THE PERCENTAGE
if __name__ == '__main__':
    n = int(input())
    student_marks = {}

    for _ in range(n):
        data = input().split()
        name = data[0]
        marks = list(map(float, data[1:]))
        student_marks[name] = marks

    query_name = input()

    average = sum(student_marks[query_name]) / 3
    print(f"{average:.2f}")
