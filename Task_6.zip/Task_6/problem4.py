# Problem 4: Loops
# HackerRank Link: https://www.hackerrank.com/challenges/python-loops/problem

if __name__ == '__main__':
    n = int(input())
    for i in range(n):
        print(i * i)
