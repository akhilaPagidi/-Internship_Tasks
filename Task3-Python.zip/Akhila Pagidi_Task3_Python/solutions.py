def frequency(sentence):
    words=sentence.split(' ')
    dic={}
    for word in words:
        dic[word]=dic.get(word,0)+1
    return dic
    
#Q2. Find the Frequency of Each Character in a Word

def frequency1(word):
    dic={}
    for i in word:
        dic[i]=dic.get(i,0)+1
    return dic

# Q3. Find the First Non-Repeating Character in a Word

def non_repeating_first(word):
    for i in word:
        if word.count(i)==1:
            return i

#Q4. Check Whether Two Strings Are Anagrams

def anagram(word1,word2):
    if sorted(word1)==sorted(word2):
        return 'anagrams'
    return 'not anagrams'

#Q5. Find the First Repeating Character in a String
def first_repeating(word):
    for i in word:
        if word.count(i)>1:
            return i
    return None

#Q6. Move All Zeros to the End of a List
def move_zero(x):
    for i in x:
        if i==0:
            x.remove(i)
            x.append(i)
    return x


#Q7. Find the Second Highest Distinct Number in a List
def second_highest(x):
    x = x.copy()
    if len(set(x)) < 2:
        return None
    maximum = max(x)
    while maximum in x:
        x.remove(maximum)
    return max(x)
            
#Remove Duplicates Without Changing the Original Order

def duplicates_remove(x):
    y=[]
    for i in x:
        if i not in y:
            y.append(i)
    return y

# Find the Missing Number from 1 to N

def missing_number(x):
    total=0
    for i in x:
        total+=i
    sum_total=0
    for i in range(len(x)+2):
        sum_total+=i
    return sum_total-total

#Q10. Find Two Numbers Whose Sum Equals a Target

def sum_target(nums, target):
    x = []

    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if nums[i] + nums[j] == target:
                x.append([nums[i], nums[j]])

    return x[0]

#Q11. Find the Number Closest to Zero

def closest_to_zero(x):
    smallest=x[0]
    for i in x:
        if abs(i)<abs(smallest):
            smallest=i
        elif abs(i)==abs(smallest) and i>smallest:
            smallest=i
    return smallest


#Q12. Find Common Elements Between Two Lists

def common_elements(x,y):
    l=[]
    for i in x:
        if i in y:
            l.append(i)
    return l

#Q13. Rotate a List to the Right by K Positions
def shift_list(x,k):
    n=len(x)
    k=k%n
    return x[-k:]+x[:-k]


#Q14. Find the Maximum Sum of Two Consecutive Elements
def two_consecutive(x):
    l=[]
    for i in range(len(x)-1):
        y=x[i]+x[i+1]
        l.append(y)
    z=l[0]
    for j in l:
        if j>z:
            z=j
    return z

# Find All Pairs of Numbers Whose Sum Equals a Target

def sum_target2(nums, target):
    x = []

    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if nums[i] + nums[j] == target:
                x.append([nums[i], nums[j]])

    return x





