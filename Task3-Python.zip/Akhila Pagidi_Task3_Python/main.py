from solutions import frequency
sample="python is easy and python is powerful"
result =frequency(sample)
print(result)

from solutions import frequency1
sample2='banana'
result=frequency1(sample2)
print(result)

from solutions import non_repeating_first
sample3="swiss"
result=non_repeating_first(sample3)
print(result)


from solutions import anagram
print(anagram('silent','listen'))


from solutions import anagram
print(anagram('st','listen'))

from solutions import first_repeating
print(first_repeating('programming'))


from solutions import move_zero
print(move_zero([0, 3, 0, 1, 2, 0, 4]))


from solutions import second_highest
print(second_highest([10, 20, 40, 30, 40, 20]))

from solutions import duplicates_remove
print(duplicates_remove([4, 2, 4, 5, 2, 7, 5]))

from solutions import missing_number
print(missing_number( [1, 2, 4, 3, 6]))

from solutions import sum_target
print(sum_target([11,7,2, 15],9))

from solutions import closest_to_zero
print(closest_to_zero([-8, -3, 2, 5, -2]))

from solutions import common_elements
print(common_elements( [1, 2, 3, 4, 5],[3, 4, 5, 6, 7]))

from solutions import shift_list
print(shift_list( [1, 2, 3, 4, 5],2))

from solutions import two_consecutive
print(two_consecutive([4, 7, 2, 9, 5]))


from solutions import sum_target2
print(sum_target2( [2, 4, 3, 5, 7, 8, 1],9))
